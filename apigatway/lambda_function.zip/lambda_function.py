def lambda_handler(event, context):
    return {
        'statusCode': 200,
        'body': 'welcome to Api gateway and with lambda!'
    }